package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class Controller {
	stack stack1 = new stack(10);
	@FXML TextField textf;
	@FXML HBox hbox;
	@FXML public void TextAction (ActionEvent e) {
		
	}
	@FXML public void PushAction (ActionEvent e) {
     
         	 Label label1 = new Label();
             label1.setText(textf.getText());
             stack1.push(label1);
             textf.clear();
             label1.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(2))));
             label1.setMinWidth(50);
             label1.setMinHeight(50);
             label1.setFont(new Font(30));
             label1.setAlignment(Pos.CENTER);
             //label1.setMaxWidth(50);     
             hbox.getChildren().add(label1);
         }
	 @FXML public void PopAction (ActionEvent e) {
		 if(!stack1.isEmpty())
			 hbox.getChildren().remove(stack1.pop());
	 }

}
