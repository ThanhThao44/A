package application;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


	public class Main extends Application {
		Scene scene1, scene2, scene3;
		@Override
		public void start(Stage primaryStage) throws Exception {
			  
		       // Create TitledPane.
		       TitledPane titledPane = new TitledPane();
		       titledPane.setText("Topic 2");
		 
		       // Content for TitledPane
		       VBox content = new VBox();
		       Button button1 = new Button("Stack");	 
		       Button button2 = new Button("LinkedList");
		       Button button3 = new Button("BalancedTree");
		       
		       content.getChildren().add(button1);
		       content.getChildren().add(button2);
		       content.getChildren().add(button3);      
		       titledPane.setContent(content);
		       
		       // Set Expaneded.
		       titledPane.setExpanded(true);     
		       VBox root= new VBox();
		       root.setPadding(new Insets(5));
		       root.getChildren().add(titledPane);
		       Scene scene = new Scene(root, 500, 300);
		       primaryStage.setTitle("Nhom_1");
		       primaryStage.setScene(scene);
		       primaryStage.show();
		       
		       
		       button1.setOnAction(new EventHandler<ActionEvent>() {
		    	   
		            @Override
		            public void handle(ActionEvent event) {
		            	Stage window1 = new Stage();
		            	try {
		    				Parent root1 = FXMLLoader.load(getClass().getResource("stacklayout.fxml"));
		    				window1.setScene(new Scene(root1));
		    				window1.setTitle("Stack");
		    				window1.show();
		    			} catch(Exception e) {
		    				e.printStackTrace();
		    			}
		            }
		       });
		   }   
		
		public static void main(String[] args) {
			launch(args);
		}
	}
