package application;

import javafx.scene.control.Label;

public class stack {
	   private int maxSize;
	   private Label[] stackArray;
	   private int top;
	   public stack(int s) {
	      maxSize = s;
	      stackArray = new Label[maxSize];
	      top = -1;
	   }
	   public void push(Label j) {
	      stackArray[++top] = j;
	   }
	   public Label pop() {
	      return stackArray[top--];	      
	   }
	   public Label peek() {
	      return stackArray[top];
	   }
	   public boolean isEmpty() {
	      return (top == -1);
	   }
	   public boolean isFull() {
	      return (top == maxSize - 1);
	   }
	}
